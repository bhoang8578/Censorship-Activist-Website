var displayName = document.getElementById("message");
var button = document.getElementById("submit");

var nameVal = document.getElementById("q2Answer"); 
var state = document.getElementById("dropdown"); 

button.addEventListener("click", () => {

  var selected = state.options.selectedIndex;
  var stateName = state.options[selected].innerHTML;

  displayName.innerHTML = 'Thank you ' + nameVal.value + ' from ' + stateName + ' for your response!';
}); 