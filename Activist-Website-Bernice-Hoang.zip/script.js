//book cover slide show on the main page from w3schools//
let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}
//generating a message on support page//
var displayName = document.getElementById("message");
var button = document.getElementById("submit");

if (button)
{
  button.addEventListener("click", showMessage);
}

function showMessage()
  {
    var name = document.getElementById('q2Answer');
    var state = document.getElementById('q3Answer');
    displayName.innerHTML = 'Thank you ' + name + ' from ' + state + ' for your response!';
    console.log('print');
  }
